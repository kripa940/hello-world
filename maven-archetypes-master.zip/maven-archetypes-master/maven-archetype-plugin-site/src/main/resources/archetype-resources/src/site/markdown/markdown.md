Markdown Format works
---------------

You can write your documentation in Markdown...

<!-- MACRO{toc|fromDepth=1|toDepth=2} -->

### Subsection

If you want to filter content with Velocity (files ending in `.vm`), please have a look at
explanations on [Markdown conflict with Velocity on `##` syntax](./markdown-velocity.html).